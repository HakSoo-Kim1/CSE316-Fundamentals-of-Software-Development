import React from 'react';

const Logo = (props) => {
    return (
        <div className='logo'>
            Todo Tracker
        </div>
    );
};

export default Logo;